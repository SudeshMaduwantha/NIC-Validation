#include <stdio.h>
#include <stdlib.h>
#define this is NIC validation programm
#define developed by sudesh maduwantha
#define DK|TECH (PVT) LTD



int length_1,T;
char NIC_NEW[12];
char NIC[12];

int main()
{
    printf("Enter The NIC Number:");
    scanf("%s",NIC);
    NIC_VALIDATE(NIC);
    return 0;
}

void NIC_VALIDATE(char nic)
{
    for(int a=0;a<12;a++)
    {
        if(NIC[a]=='~'||NIC[a]=='!'||NIC[a]=='@'||NIC[a]=='#'||NIC[a]=='$'||NIC[a]=='%'||NIC[a]=='^'
        ||NIC[a]=='&'||NIC[a]=='*'||NIC[a]=='('||NIC[a]==')'||NIC[a]=='+'||NIC[a]=='=')
        {
            printf("\nINVALID NIC FORMAT! TRY AGAIN \n");
            continue ;
        }
        //printf("%c",NIC[a]);
    }
    length_1=strlen(NIC);
    if(length_1==9)
        {
            NIC_VALIDATE_OLD(NIC);
        }
    else if(length_1<12)
        {
            printf("\nINVALID NIC FORMAT! TRY AGAIN \n");
            return 0 ;
        }
    else if(length_1>12)
        {
            printf("\nINVALID NIC FORMAT! TRY AGAIN \n");
            return 0 ;
        }
    else
        {
            for(int a=0;a<12;a++)
             {
                NIC_NEW[a]=NIC[a];
             }
            NIC_VALIDATE_NEW(NIC_NEW);
        }

}
void NIC_VALIDATE_OLD(char nic_old)
{
    if(length_1==9)
    {
       if( NIC[8]=='v'|| NIC[8]=='V')
       {
           printf("%s",NIC);
       }
       else
       {
            for(int a=65;a<123;a++)
            {
                if(NIC[8]==a)
                {
                    printf("\nINVALID NIC FORMAT! TRY AGAIN \n");
                    return 0;
                }

            }
       }
    }

}

void NIC_VALIDATE_NEW(char nic_new[])
{


    if(length_1==12)
    {
       for(int a=0;a<12;a++)
        {
            for(int b=48;b<58;b++)
            {
                if(nic_new[a]!=b)
                {
                    printf("->YOUR NIC: %s",nic_new);
                    return 0;
                }

            }
        }
        printf("\nINVALID NIC FORMAT! TRY AGAIN \n");
        return 0;

    }
}
